/**
 * 
 * 我的简历页面用到的js文件
 * 
 */



$(function(){
	
	
	$("#uploadNewResume").fileinput({'showUpload':false, 'previewFileType':'any'}); 
	
	
});












