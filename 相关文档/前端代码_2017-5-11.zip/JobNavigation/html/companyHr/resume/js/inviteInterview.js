/**
 * 
 * 邀请面试页面用到的js文件
 * 
 */


$(function(){
	
	
	
	/*提交按钮*/
	$("#submitBtn").click(function(){
		
		/*数据校验*/
		
		/*提交请求*/
		
		window.parent.location.href="http://www.baidu.com/";
		
	});
	
	
	
	
	
	
	
	
	
	
	
	
	
	
});


















