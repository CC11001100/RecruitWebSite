/**
 * 
 * 注册页面用到的js文件
 * 
 * 
 */



$(function(){
	
	
	
	
	
	$("#avatar").fileinput({'showUpload':false, 'previewFileType':'any'}); 
	
	
	
	
	
	
	
});

















